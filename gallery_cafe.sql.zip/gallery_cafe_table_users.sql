
-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_type` enum('customer','admin','staff') NOT NULL DEFAULT 'customer'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `user_type`) VALUES
(1, 'noel', 'noel@gmail.com', '$2y$10$UmjODXOz8NHUiBzix97apONblNt0uLQJtgeae5leXBquzEnJrPiQm', 'customer'),
(4, 'nadmin', 'admin_email@example.com', '<?= password_hash(\"noel123\", PASSWORD_DEFAULT) ?>', 'admin'),
(5, 'loshiadmin', 'loshi@gmail.com', 'loshi1234', 'admin'),
(7, 'noel1', 'noel@gmai1l.com', '$2y$10$OIv92NMZnReO0F4Z1ySRZOjsGrz0BHJyH9O7BPTASoXULvEdih1hK', 'customer');
