
-- --------------------------------------------------------

--
-- Table structure for table `reservations`
--

CREATE TABLE `reservations` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `table_number` int(11) NOT NULL,
  `status` enum('Pending','Confirmed','Declined') DEFAULT 'Pending',
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `reservation_date` date NOT NULL,
  `reservation_time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reservations`
--

INSERT INTO `reservations` (`id`, `user_id`, `table_number`, `status`, `date`, `reservation_date`, `reservation_time`) VALUES
(2, 1, 2, 'Pending', '2024-09-28 17:39:14', '2024-09-28', '02:13:00'),
(3, 1, 2, 'Pending', '2024-10-01 07:15:06', '2024-10-17', '14:45:00');
